# EECS6893 HW1

## 2. Question2

## (1) Download and setup Hadoop

Set up the namenode

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled.png)

verify hadoop dfs

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled%201.png)

verify yarn scrpit

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled%202.png)

### (2) HDFS metrics monitoring

- Monitor HDFS metrics through HTTP API. Provide a screenshot.

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled%203.png)

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled%204.png)

- Select five metrics that you think are most important. Explain their usages
and why they are important.

### (3) MapReduce counters monitoring

- Collect MapReduce counters related information through the web UI.
Provide a screenshot.

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled%205.png)

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled%206.png)

- Describe how to monitor the execution of MapReduce tasks through
related metrics. (5%)

### (4) YARN metrics monitoring

- Monitor YARN metrics through HTTP API. Provide a screenshot in your
report.

![Untitled](EECS6893%20HW1%206edb2baf5bdf4427be5c316d4ecefa97/Untitled%207.png)

- Select five metrics that you think are most important from the returned
json. Explain their usages and why they are important.